import React from "react";
import PageTitle from "../../Components/PageTitle/PageTitle";

const Contact = () => {
  return (
    <>
      <PageTitle PageTitle="Let's Connect" />
    </>
  );
};

export default Contact;
